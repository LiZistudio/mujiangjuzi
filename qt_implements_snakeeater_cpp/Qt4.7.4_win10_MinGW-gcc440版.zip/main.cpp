#include "widget.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <QApplication>

int main(int argc, char *argv[])
{
    srand(time(NULL));
    QApplication a(argc, argv);
    Widget w;
    w.show();

    return a.exec();
}
