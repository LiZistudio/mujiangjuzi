MinGW: http://en.sourceforge.jp/projects/sfnet_nasame2013/downloads/sources/MinGW-gcc440_1.zip/

Qt4.7.4_mingw: http://download.qt-project.org/archive/qt/4.7/

Qt Creator 4.5.2:  http://download.qt.io/official_releases/qtcreator/