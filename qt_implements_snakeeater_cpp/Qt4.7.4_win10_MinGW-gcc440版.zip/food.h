#ifndef FOOD_H
#define FOOD_H

#include <QLabel>

class Food : public QLabel
{
    Q_OBJECT
public:
    explicit Food(QWidget *parent = 0);

signals:

public slots:

};

#endif // FOOD_H
