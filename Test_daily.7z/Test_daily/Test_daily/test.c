#define _CRT_SECURE_NO_WARNINGS 1

#include <stdio.h>
#include <string.h>

char* huiwen(char* str)
{
	char* p1 = str;
	char* p2 = str + strlen(str)-1;
	int i = 0;
	int t = 0;
	for ( i = 0; i <= strlen(str)/2; i++)
	{
		if (*p1++ != *p2--)
		{
			t = 1;
			break;
		}
	}
	if (t==0)
		return "yes";
	else
		return "no";
}
int main()
{
	char str[50];
	printf("Input:");
	scanf("%s", str);
	printf("%s\n", huiwen(str));
	return 0;
}